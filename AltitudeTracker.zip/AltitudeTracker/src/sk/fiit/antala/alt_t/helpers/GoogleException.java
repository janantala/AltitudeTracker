package sk.fiit.antala.alt_t.helpers;

/***********************************************************************************
 *  	Google API Exception
 */

@SuppressWarnings("serial")
public final class GoogleException extends Exception 
{
	public GoogleException()
	{
	}
}
