package sk.fiit.antala.alt_t.helpers;

/***********************************************************************************
 *  	GPX file Exception
 */

@SuppressWarnings("serial")
public class GpxException extends Exception 
{
	public GpxException()
	{
	}
}
