AltitudeTracker
Autor: Jan Antala
Verzia: 1.0

Aplikácia Altitude Tracker analyzuje používateľom zadaný gpx súbor a následne na prehľadnom obrázku zobrazí profil trasy zo zadaného gpx súboru. Trasa ja farebne rozlíšená na základe stúpania na každom úseku trasy.
